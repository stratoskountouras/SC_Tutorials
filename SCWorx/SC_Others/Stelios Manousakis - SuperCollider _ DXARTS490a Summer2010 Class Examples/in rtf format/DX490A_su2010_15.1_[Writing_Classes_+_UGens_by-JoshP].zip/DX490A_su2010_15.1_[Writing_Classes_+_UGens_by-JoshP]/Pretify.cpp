/*
 *  Pretify.cpp
 *  xSC3plugins
 *
 *  Created by Josh Parmenter on 2/4/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */
/*
	SuperCollider real time audio synthesis system
    Copyright (c) 2002 James McCartney. All rights reserved.
	http://www.audiosynth.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
*/


// MUST include this header
#include "SC_PlugIn.h"

// these two defines are found in other parts of the source code - they allow for some fast random number generation
#define RGET \
	RGen& rgen = *unit->mParent->mRGen; \
	uint32 s1 = rgen.s1; \
	uint32 s2 = rgen.s2; \
	uint32 s3 = rgen.s3; 

#define RPUT \
	rgen.s1 = s1; \
	rgen.s2 = s2; \
	rgen.s3 = s3;


// need to reference the InterfaceTable
static InterfaceTable *ft;


// use structs to store the state of a UGen . The name should be the same as the UGen - this is allocated for 
// you when you create a new instance of the UGen. It inherits from Unit (which all UGens use at some point)
struct Pretify : public Unit
{
    float indexVal;
};

// declare unit generator functions 
extern "C"
{
    void load(InterfaceTable *inTable);
    
    void Pretify_next(Pretify *unit, int inNumSamples);
    void Pretify_Ctor(Pretify* unit);
}

// Depending on the kind of Unit you defince (Simple, Dtor, etc.) sc defines functions based on the UGen name
// that are accessed when a UGen is called for. There are _Ctor (constructor) functions and _Dtor (destructor) 
// functions (in the case of DtorUnits) that are called by scsynth when appropriate.

// Ctor is called - basically allocates the memory needed for the struct (or - passes the memory as a pointer
// into the Ctor function), and then allows you to initialize the state of the UGen AND calcualte the first 
// sample

void Pretify_Ctor(Pretify* unit)
{
	// SETCALC is a macro that tells scsynth which function to call next
	// usually a _next function, but in reality it can just about be anything that takes
	// the UGen struct and the number of samples to calculate
	SETCALC(Pretify_next);
    
	// use the IN0 macro to grab the current index, and store it in the struct
	unit->indexVal = IN0(1);
	// output 0 for one sample ...
	// ClearUnitOutputs(unit, 1);
	// OR actually calcualte a sample by calling the _next functions
	Pretify_next(unit, 1);
}

void Pretify_next(Pretify* unit, int inNumSamples)
{
    // we have two inputs - an audio input and a k-rate index val
    // the audio in (accessed with the IN macro) is a pointer of floats of inNumSamples length
    float *in = IN(0);
    // setup the output pointer using OUT
    float *out = OUT(0);
    // now - for k-rate inputs, we want to get the last sample stored in the struct:
    float indexVal = unit->indexVal;
    // and we will linearly interpolate to whatever the new value is:
    float newIndexVal = IN0(1);
    // CALCSLOPE will give us the difference / inNumSamples
    float indexValSlope = CALCSLOPE(newIndexVal, indexVal);
    
    // we are going to add noise to our input, so use the RGET macro above to get the register state
    RGET
    
    // now - we can loop through the block and calculate new samples
    for(int i = 0; i < inNumSamples; i++)
    {
	float ran = frand2(s1, s2, s3); // s1, s2 and s3 are defined in the macro
	// multiply it times the current indexVal
	ran *= indexVal;
	// add it to the current input signal, and send it out
	out[i] = in[i] + ran;
	// incrememnt indexVal with the slope
	indexVal += indexValSlope;
    }
    
    // store the current random state
    RPUT
    
    // we're done calcualting samples - store the state of indexVal back to the struct
    unit->indexVal = indexVal;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////

void load(InterfaceTable *inTable)
{
	ft = inTable;
	DefineSimpleUnit(Pretify);

}


	
